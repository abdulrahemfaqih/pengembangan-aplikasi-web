<?php include "layout/header.php" ?>
<h1 style="text-align: center; margin: 5rem;">Selamat Datang di Warung Faqih</h1>
<?php include "layout/footer.php" ?>